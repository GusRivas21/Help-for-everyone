const express = require('express');
const rutas = express.Router();
const Viviendas = require('../modelos/viviendas');

rutas.get('/', async (req, res) => {
    try {
        const bakhogares = await Viviendas.find();
        res.json(bakhogares);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

rutas.post('/', async (req, res) => {
    const hogar = new Viviendas({
        representante: req.body.representante,
        nombre: req.body.nombre,
        habitantes: req.body.habitantes,
        direccion: {
            colonia: req.body.direccion?.colonia,
            referencia: req.body.direccion?.referencia,
            numero: req.body.direccion?.numero,
        },
        salariopromedio: req.body.salariopromedio,
    });

    try {
        const nuevoHogar = await hogar.save();
        res.status(201).json(nuevoHogar);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

rutas.get('/:id', getHogar, (req, res) => {
    res.json(res.hogar);
});

async function getHogar(req, res, next) {
    let hogar;
    try {
        hogar = await Viviendas.findById(req.params.id);
        if (hogar == null) {
            return res.status(404).json({ message: 'El hogar no fue encontrado' });
        }
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
    res.hogar = hogar;
    next();
}

rutas.put('/:id', getHogar, async (req, res) => {
    if (req.body.representante) {
        res.hogar.representante = req.body.representante;
    }
    if (req.body.nombre) {
        res.hogar.nombre = req.body.nombre;
    }
    if (req.body.habitantes) {
        res.hogar.habitantes = req.body.habitantes;
    }
    if (req.body.direccion) {
        if (req.body.direccion.colonia) {
            res.hogar.direccion.colonia = req.body.direccion.colonia;
        }
        if (req.body.direccion.referencia) {
            res.hogar.direccion.referencia = req.body.direccion.referencia;
        }
        if (req.body.direccion.numero) {
            res.hogar.direccion.numero = req.body.direccion.numero;
        }
    }
    if (req.body.salariopromedio) {
        res.hogar.salariopromedio = req.body.salariopromedio;
    }

    try {
        const hogarActualizado = await res.hogar.save();
        res.json(hogarActualizado);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

rutas.delete('/:id', getHogar, async (req, res) => {
    try {
        await Viviendas.findByIdAndDelete(req.params.id);
        res.json({ message: 'Hogar eliminado exitosamente' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = rutas;
