const mongoose = require('mongoose') 

const hogarSchema = new mongoose.Schema({
    representante: String,
    nombre: String,
    habitantes: Number,
    direccion:{
        colonia: String,
        referencia: String,
        numero: Number
   },
    salariopromedio: Number
   
})

const bakhogares = mongoose.model('hogares', hogarSchema)

module.exports = bakhogares